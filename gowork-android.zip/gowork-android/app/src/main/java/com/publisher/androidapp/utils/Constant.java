package com.publisher.androidapp.utils;

public class Constant {

    static String SERVER_URL = "http://gowork.ldpfilehost.web.id/";

    public static String STR_ID = "str_id";
    public static String STR_HAK_AKSES = "str_hak_akses";

    public static String HAK_AKSES_TUNA_KARYA = "Tuna Karya";
    public static String HAK_AKSES_RELAWAN = "Relawan";

}
